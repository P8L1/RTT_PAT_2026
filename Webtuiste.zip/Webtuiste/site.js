const pages = [
    ["index.html", "Titelblad"],
    ["bevindinge.html", "Bevindinge"],
    ["bibliografie.html", "Bibliografie"],
  ],
  current = document.body.dataset.page;
const links = pages
  .map(
    ([href, label]) =>
      `<a href="${href}" class="rounded-full px-4 py-2 font-bold ${label === current ? "bg-amber-300 text-slate-950" : "hover:bg-white/10"}" ${label === current ? 'aria-current="page"' : ""}>${label}</a>`,
  )
  .join("");
